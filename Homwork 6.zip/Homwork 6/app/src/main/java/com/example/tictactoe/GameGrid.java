package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class GameGrid extends AppCompatActivity {

    String p1;
    String p2;
    TextView turn;
    Boolean player1Turn;
    int roundCounter = 0;
    public static int[][] table = new int[3][3];
    public static int maxTime = 7000, interval =1000;
    public static int count = maxTime/interval;
    public static CountDownTimer cdt;
    int id;
    ImageButton chosen;
    public String stText;
    int currentPlayer;
    private FileOutputStream fos;
    private OutputStreamWriter osw;
    private BufferedWriter bw;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_grid);

        Intent intent = getIntent();
        p1 = intent.getStringExtra(MainActivity.P1);
        p2 = intent.getStringExtra(MainActivity.P2);
        turn = (TextView) findViewById(R.id.PlayerTurn);
        player1Turn = true;
        TableValues();
        turn.setText(p1 + " Turn");
    }
    public void onClick (View view){
                chosen = (ImageButton) view;
                if (player1Turn)
                    chosen.setImageResource(R.drawable.x);
                else
                    chosen.setImageResource(R.drawable.o);
                roundCounter++;
                id = view.getId();
                currentPlayer = CurrentPlayer(player1Turn);
                table = FindPlacementById(table,id,currentPlayer);
                if (CheckColumns(currentPlayer)||CheckRows(currentPlayer)||CheckDiagonal(currentPlayer)) {
                    finish();
                   Toast.makeText(GameGrid.this, "Player number " + currentPlayer + " won!!", Toast.LENGTH_LONG).show();
                   Toast.makeText(GameGrid.this, "Thanks for playing. See you next time! ", Toast.LENGTH_LONG).show();
                   endGame();
                }
                else if (roundCounter >= 9) {
                    Toast.makeText(GameGrid.this, "Its a tie!!", Toast.LENGTH_LONG).show();
                    Toast.makeText(GameGrid.this, "Thanks for playing. See you next time! ", Toast.LENGTH_LONG).show();
                    endGame();
                }
                else {
                    if (player1Turn) {
                        player1Turn = false;
                        turn.setText(p2 + " Turn");
                    }
                    else {
                        player1Turn = true;
                        turn.setText(p1 + " Turn");
                    }
                }
            }
    public static void TableValues() {
        for (int i = 0; i < table.length; i++) {
            for (int g=0; g< table[i].length;g++)
                    table[i][g] = 0;
            }
        }
    public static boolean CheckColumns(int i) {
        for (int j = 0; j < 3; j++){
            if ((table[0][j] == i && table[1][j] == i && table[2][j] == i)) {
                return true;
            }
        }
        return false;
    }
    public static boolean CheckRows(int i){
        for (int j = 0; j < 3; j++) {
            if ((table[j][0] == i && table[j][1] == i && table[j][2] == i)) {
                return true;
            }
        }
        return false;
    }
    public static boolean CheckDiagonal(int i){
        if ((table[0][0] == i && table[1][1] == i && table[2][2] == i) ||(table[0][2] == i && table[1][1] == i && table[2][0] == i)) {
            return true;
        }
        return false;
    }
    public static int CurrentPlayer(boolean player1Turn) {
        int i;
        if (player1Turn)
            i = 1;
        else
            i = 2;
        return i;
    }
    public static int[][] FindPlacementById(int[][] table, int id, int i) {
        if (id == R.id.zeroZero){
            table[0][0] = i;}
        else if (id == R.id.zeroOne){
            table[0][1] = i;}
        else if (id == R.id.zeroTwo){
            table[0][2] = i;}
        else if (id == R.id.oneZero){
            table[1][0] = i;}
        else if (id == R.id.oneOne){
            table[1][1] = i;}
        else if (id == R.id.oneTwo){
            table[1][2] = i;}
        else if (id == R.id.twoZero){
            table[2][0] = i;}
        else if (id == R.id.twoOne){
            table[2][1] = i;}
        else if (id == R.id.twoTwo){
            table[2][2] = i;}
        return table;
    }
    public void endGame(){
        cdt=new CountDownTimer(maxTime,interval) {
            @Override
            public void onTick(long millisUntilFinished) {
                count--;
            }

            @Override
            public void onFinish() {
                finish();//Close App
                System.exit(0);
            }
        }.start();
        try {
            fos = openFileOutput("txt.txt", Context.MODE_APPEND);
            osw=new OutputStreamWriter(fos);
            bw = new BufferedWriter(osw);
            bw.append(stText);
            bw.close();
        } catch (FileNotFoundException e) {
            Toast.makeText(this,"ERROR",Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this,"ERROR",Toast.LENGTH_SHORT).show();
        }
        File myDir= new File("data/data/"+getPackageName()+"/txtFile");
        myDir.mkdir();
        File myFile=new File(myDir,"txt");
    }
}

