package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class GameGrid extends AppCompatActivity {

    String p1;
    String p2;
    TextView turn;
    Boolean player1Turn;
    int roundCounter = 0;
    public static int[][] table = new int[3][3];
    public static int maxTime = 7000, interval =1000;
    public static int count = maxTime/interval;
    public static CountDownTimer cdt;
    String id;
    Toast toast;
    ImageButton chosen;
    int i;
    int currentPlayer;
    boolean active = true;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_grid);

        Intent intent = getIntent();
        p1 = intent.getStringExtra(MainActivity.P1);
        p2 = intent.getStringExtra(MainActivity.P2);
        turn = (TextView) findViewById(R.id.PlayerTurn);
        player1Turn = true;
        TableValues();
        turn.setText(p1 + " Turn");
    }
    public void onClick (View view) {
        if (active) {
            chosen = (ImageButton) view;
            id = FindByIntId(view.getId());
            if(IsEmpty()) {
                if (player1Turn) {
                    chosen.setImageResource(R.drawable.x);
                    i = 1;
                } else {
                    chosen.setImageResource(R.drawable.o);
                    i = 2;
                }
                roundCounter++;
                currentPlayer = CurrentPlayer(player1Turn);
                FindPlacementById(i);
                if (CheckColumns(currentPlayer) || CheckRows(currentPlayer) || CheckDiagonal(currentPlayer)) {
                    active = false;
                    toast=Toast.makeText(GameGrid.this, "Player number " + currentPlayer + " won!!", Toast.LENGTH_LONG);
                    toast.show();
                    EndGame();
                } else if (roundCounter >= 9) {
                    active = false;
                    toast=Toast.makeText(GameGrid.this, "Its a tie!!", Toast.LENGTH_LONG);
                    toast.show();
                    EndGame();
                } else {
                    if (player1Turn) {
                        player1Turn = false;
                        turn.setText(p2 + " Turn");
                    } else {
                        player1Turn = true;
                        turn.setText(p1 + " Turn");
                    }
                }
            }
            else {
                toast=Toast.makeText(GameGrid.this, "Already chosen. Please choose a different box", Toast.LENGTH_LONG);
                toast.show();
            }
        }
    }
    public static void TableValues() {
        for (int i = 0; i < table.length; i++) {
            for (int g=0; g< table[i].length;g++)
                    table[i][g] = 0;
            }
        }
    public static boolean CheckColumns(int i) {
        for (int j = 0; j < 3; j++){
            if ((table[0][j] == i && table[1][j] == i && table[2][j] == i)) {
                return true;
            }
        }
        return false;
    }
    public static boolean CheckRows(int i){
        for (int j = 0; j < 3; j++) {
            if ((table[j][0] == i && table[j][1] == i && table[j][2] == i)) {
                return true;
            }
        }
        return false;
    }
    public static boolean CheckDiagonal(int i){
        if ((table[0][0] == i && table[1][1] == i && table[2][2] == i) ||(table[0][2] == i && table[1][1] == i && table[2][0] == i)) {
            return true;
        }
        return false;
    }
    public static int CurrentPlayer(boolean player1Turn) {
        int i;
        if (player1Turn)
            i = 1;
        else
            i = 2;
        return i;
    }
    public boolean IsEmpty(){
        boolean empty = true;
        if (id != null) {
            if (id.equals("zeroZero")) {
                if (table[0][0] != 0)
                    empty=false;
            } else if (id.equals("zeroOne")) {
                if (table[0][1] != 0)
                    empty=false;
            } else if (id.equals("zeroTwo")){
                if (table[0][2] != 0)
                    empty=false;
            } else if (id.equals("oneZero")) {
                if (table[1][0] != 0)
                    empty=false;
            } else if (id.equals("oneOne")) {
                if (table[1][1] != 0)
                    empty=false;
            } else if (id.equals("oneTwo")) {
                if (table[1][2] != 0)
                    empty=false;
            } else if (id.equals( "twoZero")) {
                if (table[2][0] != 0)
                    empty=false;
            } else if (id.equals( "twoOne")) {
                if (table[2][1] != 0)
                    empty=false;
            } else if (id.equals( "twoTwo")){
                if (table[2][2] != 0)
                    empty=false;
            }
        }
        return empty;
    }
    public String FindByIntId(int id){
        if (id == R.id.zeroZero){
            return "zeroZero";}
        else if (id == R.id.zeroOne){
            return "zeroOne";}
        else if (id == R.id.zeroTwo){
            return "zeroTwo";}
        else if (id == R.id.oneZero){
            return "oneZero";}
        else if (id == R.id.oneOne){
            return "oneOne";}
        else if (id == R.id.oneTwo){
            return "oneTwo";}
        else if (id == R.id.twoZero){
            return "twoZero";}
        else if (id == R.id.twoOne){
            return "twoOne";}
        else if (id == R.id.twoTwo){
            return "twoTwo";}
        return "";
    }
    private void FindPlacementById(int i) {
        if (id != null) {
            if (id.equals("zeroZero")) {
                table[0][0] = i;
            } else if (id.equals("zeroOne")) {
                table[0][1] = i;
            } else if (id.equals("zeroTwo")){
                table[0][2] = i;
            } else if (id.equals("oneZero")) {
                table[1][0] = i;
            } else if (id.equals("oneOne")) {
                table[1][1] = i;
            } else if (id.equals("oneTwo")) {
                table[1][2] = i;
            } else if (id.equals( "twoZero")) {
                table[2][0] = i;
            } else if (id.equals( "twoOne")) {
                table[2][1] = i;
            } else if (id.equals( "twoTwo")){
                table[2][2] = i;
            }
        }
    }
    public void EndGame(){
        cdt=new CountDownTimer(maxTime,interval) {
            @Override
            public void onTick(long millisUntilFinished) {
                count--;
            }

            @Override
            public void onFinish() {
                finish();
                System.exit(0);
            }
        }.start();
    }
}

